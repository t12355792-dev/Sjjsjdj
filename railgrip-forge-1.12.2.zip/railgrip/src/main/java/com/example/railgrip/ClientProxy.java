package com.example.railgrip;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import java.util.UUID;

@SideOnly(Side.CLIENT)
public class ClientProxy extends CommonProxy {
    @Override
    public void preInit() {
        ClientRegistry.registerKeyBinding(ClientEvents.KEY_GRIP);
        ClientRegistry.registerKeyBinding(ClientEvents.KEY_UNEQUIP);
        MinecraftForge.EVENT_BUS.register(new ClientEvents());
    }

    @Override
    public void postInit() {
        for (RenderPlayer r : Minecraft.getMinecraft().getRenderManager().getSkinMap().values()) {
            r.addLayer(new LayerGloves(r));
        }
    }

    @Override
    public void handleGlove(final long most, final long least, final boolean on) {
        Minecraft.getMinecraft().addScheduledTask(new Runnable() {
            @Override public void run() {
                UUID id = new UUID(most, least);
                if (on) ClientEvents.GLOVED.add(id); else ClientEvents.GLOVED.remove(id);
            }
        });
    }
}
