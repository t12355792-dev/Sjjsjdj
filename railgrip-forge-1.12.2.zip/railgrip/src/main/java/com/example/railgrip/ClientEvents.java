package com.example.railgrip;

import com.google.common.base.Predicate;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.input.Keyboard;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * Вся механика хвата считается на клиенте (так движение плавное):
 * G — схватиться/отпустить, W/S — вверх/вниз по поезду, A/D — вдоль вагона.
 * Шкала хвата растёт; когда заполнится, игрок падает и погибает.
 */
@SideOnly(Side.CLIENT)
public class ClientEvents {
    public static final Set<UUID> GLOVED = new HashSet<UUID>();

    public static final KeyBinding KEY_GRIP = new KeyBinding("key.railgrip.grip", Keyboard.KEY_G, "key.categories.railgrip");
    public static final KeyBinding KEY_UNEQUIP = new KeyBinding("key.railgrip.unequip", Keyboard.KEY_H, "key.categories.railgrip");

    // --- настройки баланса
    private static final float BASE_SECONDS = 45f;     // на стоящем поезде шкала заполнится за столько секунд
    private static final float GLOVE_BONUS = 1.30f;    // перчатки: хват на 30% сильнее
    private static final double CLIMB_SPEED = 0.07;    // блоков за тик

    // --- состояние хвата
    private static Entity train;
    private static int face;          // 0: -X, 1: +X, 2: -Z, 3: +Z
    private static double rel;        // положение вдоль грани относительно центра вагона
    private static double yRel;       // высота относительно низа вагона
    private static float grip = 0f;

    // --- скорость
    private static double lastX, lastY, lastZ;
    private static boolean haveLast;
    private static double speedKmh;

    private static boolean hasGloves(Minecraft mc) {
        return mc.player != null && GLOVED.contains(mc.player.getUniqueID());
    }

    // ------------------------------------------------------------ клавиши

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent e) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null || mc.world == null) return;
        while (KEY_GRIP.isPressed()) {
            if (train != null) release(mc, false);
            else tryGrab(mc);
        }
        while (KEY_UNEQUIP.isPressed()) {
            Net.CH.sendToServer(new Net.MsgUnequip());
        }
    }

    private static void tryGrab(Minecraft mc) {
        final EntityPlayerSP p = mc.player;
        AxisAlignedBB area = p.getEntityBoundingBox().grow(1.6, 0.8, 1.6);
        List<Entity> list = mc.world.getEntitiesWithinAABB(Entity.class, area, new Predicate<Entity>() {
            @Override public boolean apply(Entity e) { return e != p && TrainUtil.isTrain(e); }
        });
        Entity best = null;
        double bestD = Double.MAX_VALUE;
        for (Entity e : list) {
            AxisAlignedBB b = e.getEntityBoundingBox();
            double dx = Math.max(Math.max(b.minX - p.posX, 0), p.posX - b.maxX);
            double dz = Math.max(Math.max(b.minZ - p.posZ, 0), p.posZ - b.maxZ);
            double d = dx * dx + dz * dz;
            if (d < bestD) { bestD = d; best = e; }
        }
        if (best == null) {
            p.sendStatusMessage(new net.minecraft.util.text.TextComponentTranslation("msg.railgrip.nothing"), true);
            return;
        }
        AxisAlignedBB b = best.getEntityBoundingBox();
        if (p.posY >= b.maxY - 0.1) {
            p.sendStatusMessage(new net.minecraft.util.text.TextComponentTranslation("msg.railgrip.onroof"), true);
            return;
        }
        double dMinX = Math.abs(p.posX - b.minX), dMaxX = Math.abs(p.posX - b.maxX);
        double dMinZ = Math.abs(p.posZ - b.minZ), dMaxZ = Math.abs(p.posZ - b.maxZ);
        double m = Math.min(Math.min(dMinX, dMaxX), Math.min(dMinZ, dMaxZ));
        if (m == dMinX) face = 0; else if (m == dMaxX) face = 1; else if (m == dMinZ) face = 2; else face = 3;

        double center = (face < 2) ? (b.minZ + b.maxZ) / 2 : (b.minX + b.maxX) / 2;
        double along = (face < 2) ? p.posZ : p.posX;
        rel = along - center;
        yRel = Math.max(0, Math.min(p.posY - b.minY, b.maxY - b.minY - 0.05));
        train = best;
        p.sendStatusMessage(new net.minecraft.util.text.TextComponentTranslation("msg.railgrip.grabbed"), true);
    }

    private static void release(Minecraft mc, boolean fell) {
        EntityPlayerSP p = mc.player;
        if (train != null && p != null) {
            p.motionX = train.posX - train.prevPosX;
            p.motionY = 0;
            p.motionZ = train.posZ - train.prevPosZ;
            p.fallDistance = 0;
        }
        train = null;
        if (fell && p != null) {
            p.sendStatusMessage(new net.minecraft.util.text.TextComponentTranslation("msg.railgrip.fell"), true);
        }
    }

    // ------------------------------------------------------------ ввод

    @SubscribeEvent
    public void onInputUpdate(InputUpdateEvent e) {
        if (train != null) {
            e.getMovementInput().moveForward = 0;
            e.getMovementInput().moveStrafe = 0;
            e.getMovementInput().jump = false;
            e.getMovementInput().sneak = false;
        }
    }

    // ------------------------------------------------------------ физика хвата

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
        Minecraft mc = Minecraft.getMinecraft();
        if (e.phase != TickEvent.Phase.END || !e.side.isClient() || e.player != mc.player) return;
        if (mc.isGamePaused()) return;
        EntityPlayerSP p = mc.player;

        if (train == null) {
            grip = Math.max(0f, grip - 1f / (20f * 8f));   // рука отдыхает
            return;
        }
        if (train.isDead || p.isDead || p.capabilities.isFlying) {
            release(mc, false);
            return;
        }

        AxisAlignedBB b = train.getEntityBoundingBox();
        boolean up = mc.gameSettings.keyBindForward.isKeyDown();
        boolean down = mc.gameSettings.keyBindBack.isKeyDown();
        boolean left = mc.gameSettings.keyBindLeft.isKeyDown();
        boolean right = mc.gameSettings.keyBindRight.isKeyDown();
        double lat = (right ? 1 : 0) - (left ? 1 : 0);

        if (up) yRel += CLIMB_SPEED;
        if (down) yRel -= CLIMB_SPEED;
        if (lat != 0) {
            double yaw = Math.toRadians(p.rotationYaw);
            double rx = -Math.cos(yaw), rz = -Math.sin(yaw);       // вектор «вправо» от взгляда
            double comp = (face < 2) ? rz : rx;
            rel += lat * comp * CLIMB_SPEED;
        }
        double half = ((face < 2) ? (b.maxZ - b.minZ) : (b.maxX - b.minX)) / 2 + 0.3;
        rel = Math.max(-half, Math.min(half, rel));
        double height = b.maxY - b.minY;
        yRel = Math.max(0, yRel);

        double center = (face < 2) ? (b.minZ + b.maxZ) / 2 : (b.minX + b.maxX) / 2;
        double along = center + rel;

        // долезли до крыши
        if (up && yRel >= height - 0.02) {
            double x, z;
            if (face == 0)      { x = b.minX + 0.8; z = along; }
            else if (face == 1) { x = b.maxX - 0.8; z = along; }
            else if (face == 2) { z = b.minZ + 0.8; x = along; }
            else                { z = b.maxZ - 0.8; x = along; }
            p.setPosition(x, b.maxY + 0.02, z);
            release(mc, false);
            p.sendStatusMessage(new net.minecraft.util.text.TextComponentTranslation("msg.railgrip.roof"), true);
            return;
        }

        double x, z;
        if (face == 0)      { x = b.minX - 0.32; z = along; }
        else if (face == 1) { x = b.maxX + 0.32; z = along; }
        else if (face == 2) { z = b.minZ - 0.32; x = along; }
        else                { z = b.maxZ + 0.32; x = along; }
        p.setPosition(x, b.minY + yRel, z);
        p.motionX = 0; p.motionY = 0; p.motionZ = 0;
        p.fallDistance = 0;

        // шкала хвата
        boolean moving = up || down || lat != 0;
        float rate = 1f / (20f * BASE_SECONDS);
        rate *= 1f + (float) (speedKmh / 60.0) * 0.8f;
        if (moving) rate *= 1.35f;
        if (hasGloves(mc)) rate /= GLOVE_BONUS;
        grip += rate;
        if (grip >= 1f) {
            grip = 1f;
            release(mc, true);
            Net.CH.sendToServer(new Net.MsgFall());
        }
    }

    // ------------------------------------------------------------ скорость

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null || mc.isGamePaused()) { haveLast = false; return; }
        EntityPlayerSP p = mc.player;
        if (haveLast) {
            double dx = p.posX - lastX, dy = p.posY - lastY, dz = p.posZ - lastZ;
            double v = Math.sqrt(dx * dx + dy * dy + dz * dz) * 20.0 * 3.6;   // блок = 1 м
            if (v < 1500) speedKmh = speedKmh * 0.7 + v * 0.3;
        }
        lastX = p.posX; lastY = p.posY; lastZ = p.posZ; haveLast = true;
    }

    // ------------------------------------------------------------ HUD

    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Post e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.HOTBAR) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null || mc.gameSettings.hideGUI) return;
        ScaledResolution res = e.getResolution();
        int w = res.getScaledWidth(), h = res.getScaledHeight();

        // скоростемер
        boolean holding = mc.player.getHeldItemMainhand().getItem() == ModItems.SPEEDOMETER
                || mc.player.getHeldItemOffhand().getItem() == ModItems.SPEEDOMETER;
        if (holding) {
            String s = String.format(Locale.ROOT, "%d %s", Math.round(speedKmh), I18n.format("hud.railgrip.kmh"));
            float sc = 1.7f;
            GlStateManager.pushMatrix();
            GlStateManager.scale(sc, sc, 1f);
            int tw = mc.fontRenderer.getStringWidth(s);
            int color = speedKmh > 80 ? 0xFF5555 : (speedKmh > 40 ? 0xFFD24A : 0x7CFC8A);
            mc.fontRenderer.drawStringWithShadow(s, (w / 2f - tw * sc / 2f) / sc, (h - 62) / sc, color);
            GlStateManager.popMatrix();
        }

        // шкала хвата
        if (train != null || grip > 0.02f) {
            int bw = 110, bh = 9;
            int x = w / 2 - bw / 2, y = h - 78;
            Gui.drawRect(x - 1, y - 1, x + bw + 1, y + bh + 1, 0xFF000000);
            Gui.drawRect(x, y, x + bw, y + bh, 0xFF2B2B2B);
            int fill = (int) (bw * grip);
            int color = grip < 0.5f ? 0xFF3CC84A : (grip < 0.8f ? 0xFFE6C229 : 0xFFE0402A);
            if (grip > 0.85f && (System.currentTimeMillis() / 150) % 2 == 0) color = 0xFFFF8080;
            Gui.drawRect(x, y, x + fill, y + bh, color);
            String label = I18n.format("hud.railgrip.grip") + " " + Math.round(grip * 100) + "%"
                    + (hasGloves(mc) ? " +30%" : "");
            mc.fontRenderer.drawStringWithShadow(label, w / 2f - mc.fontRenderer.getStringWidth(label) / 2f, y - 11, 0xFFFFFF);
        }
    }
}
