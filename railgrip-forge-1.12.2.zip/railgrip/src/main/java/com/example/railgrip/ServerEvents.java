package com.example.railgrip;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;

public class ServerEvents {
    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        GloveData.sync(e.player);
    }

    @SubscribeEvent
    public void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        GloveData.sync(e.player);
    }

    @SubscribeEvent
    public void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        GloveData.sync(e.player);
    }

    /** Когда игрок начинает «видеть» другого игрока, отправляем ему состояние перчаток того. */
    @SubscribeEvent
    public void onStartTracking(net.minecraftforge.event.entity.player.PlayerEvent.StartTracking e) {
        if (e.getTarget() instanceof EntityPlayer && e.getEntityPlayer() instanceof EntityPlayerMP) {
            GloveData.sendTo((EntityPlayer) e.getTarget(), (EntityPlayerMP) e.getEntityPlayer());
        }
    }

    /** При смерти перчатки выпадают. */
    @SubscribeEvent
    public void onDeath(LivingDeathEvent e) {
        if (e.getEntityLiving() instanceof EntityPlayerMP) {
            EntityPlayerMP p = (EntityPlayerMP) e.getEntityLiving();
            if (GloveData.isEquipped(p)) {
                GloveData.setEquipped(p, false);
                p.entityDropItem(new ItemStack(ModItems.GLOVES), 0.5F);
            }
        }
    }
}
