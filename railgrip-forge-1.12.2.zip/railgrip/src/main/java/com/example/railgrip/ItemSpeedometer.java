package com.example.railgrip;

import net.minecraft.client.resources.I18n;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import javax.annotation.Nullable;
import java.util.List;

/** Скоростемер: пока он в руке, внизу экрана показывается скорость в км/ч. */
public class ItemSpeedometer extends Item {
    public ItemSpeedometer() {
        setRegistryName(RailGrip.MODID, "speedometer");
        setUnlocalizedName(RailGrip.MODID + ".speedometer");
        setCreativeTab(CreativeTabs.TRANSPORTATION);
        setMaxStackSize(1);
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void addInformation(ItemStack stack, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
        tooltip.add(I18n.format("tooltip.railgrip.speedometer"));
    }
}
