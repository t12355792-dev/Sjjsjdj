package com.example.railgrip;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/** Слой рендера: перчатки на руках игрока. */
@SideOnly(Side.CLIENT)
public class LayerGloves implements LayerRenderer<EntityLivingBase> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(RailGrip.MODID, "textures/models/gloves.png");

    private final RenderPlayer renderer;
    private final ModelBiped model = new ModelBiped(0.28F);

    public LayerGloves(RenderPlayer renderer) {
        this.renderer = renderer;
        model.bipedHead.showModel = false;
        model.bipedHeadwear.showModel = false;
        model.bipedBody.showModel = false;
        model.bipedRightLeg.showModel = false;
        model.bipedLeftLeg.showModel = false;
        model.bipedRightArm.showModel = true;
        model.bipedLeftArm.showModel = true;
    }

    @Override
    public void doRenderLayer(EntityLivingBase entity, float limbSwing, float limbSwingAmount, float partialTicks,
                              float ageInTicks, float netHeadYaw, float headPitch, float scale) {
        if (!(entity instanceof EntityPlayer)) return;
        if (!ClientEvents.GLOVED.contains(entity.getUniqueID())) return;
        if (entity.isInvisible()) return;

        Minecraft.getMinecraft().getTextureManager().bindTexture(TEXTURE);
        model.setModelAttributes(renderer.getMainModel());
        model.setLivingAnimations(entity, limbSwing, limbSwingAmount, partialTicks);
        model.setRotationAngles(limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, entity);

        GlStateManager.enableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.blendFunc(770, 771);
        model.render(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
        GlStateManager.disableBlend();
    }

    @Override
    public boolean shouldCombineTextures() {
        return false;
    }
}
